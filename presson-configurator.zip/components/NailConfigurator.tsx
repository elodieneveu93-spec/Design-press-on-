
'use client'
import React, { useMemo, useState } from 'react';
import { jsPDF } from 'jspdf';

const PRESETS = [
  { label: 'Doux & poétique', shape: 'amande', length: 'moyenne', colors: 'bleu pastel, nude rosé', motifs: 'petites fleurs blanches, paillettes très fines', vibe: 'léger, romantique, lumineux' },
  { label: 'Glam rock', shape: 'coffin court', length: 'courte', colors: 'noir mat, chrome argent', motifs: 'french inversée fine, accents métalliques', vibe: 'audacieux, soirée, edgy' },
  { label: 'Minimal chic', shape: 'ovale court', length: 'courte', colors: 'nude beige, blanc', motifs: 'french fine, demi‑lune', vibe: 'propre, bureau, quotidien' },
  { label: 'Mariée lumineuse', shape: 'amande', length: 'longue', colors: 'lilas très pâle, blanc nacré', motifs: 'babyboomer, nacres subtiles', vibe: 'élégant, photo‑ready, intemporel' },
  { label: 'Pastel romantique', shape: 'amande', length: 'moyenne', colors: 'rose poudré, lilas, ivoire', motifs: 'micro‑fleurs, traits fins dorés', vibe: 'printanier, féminin, délicat' },
  { label: 'Classique nude', shape: 'ovale', length: 'moyenne', colors: 'nude rosé, blanc doux', motifs: 'french subtile', vibe: 'sobre, épuré, chic' },
];

function Tip({ index, src }: { index: number; src: string }) {
  return (
    <div className="relative w-20 h-24 md:w-24 md:h-28 flex items-center justify-center">
      <div className="absolute inset-0 rounded-b-[40px] rounded-t-[14px] bg-white/70 shadow" />
      <img src={src} alt={`échantillon ${index + 1}`} className="relative z-10 w-16 h-20 md:w-20 md:h-24 object-cover rounded-b-[36px] rounded-t-[12px]" />
    </div>
  );
}

export default function NailConfigurator() {
  const [shape, setShape] = useState('');
  const [colors, setColors] = useState('');
  const [motifs, setMotifs] = useState('');
  const [vibe, setVibe] = useState('');
  const [length, setLength] = useState('');

  const [knowSizes, setKnowSizes] = useState(false);
  const [sizesLeft, setSizesLeft] = useState(['', '', '', '', '']);
  const [sizesRight, setSizesRight] = useState(['', '', '', '', '']);
  const [notes, setNotes] = useState('');

  const [prompt, setPrompt] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const wood = "https://images.unsplash.com/photo-1541080477408-659cf03d4d92?q=80&w=1600&auto=format&fit=crop";

  function buildPrompt() {
    const parts = [
      shape && `Forme: ${shape}`,
      length && `Longueur: ${length}`,
      colors && `Couleurs: ${colors}`,
      motifs && `Motifs/déco: ${motifs}`,
      vibe && `Ambiance/style: ${vibe}`,
    ].filter(Boolean);

    const base = `Génère une photo réaliste d'un nuancier de press-on nails présenté sur une planche en bois clair, lumière douce studio, focus sur les tips, style e-commerce.`;
    const constraints = `Pas de logos/licences, rendu propre, arrière-plan minimal, alignement régulier des échantillons.`;
    const full = `${base}\n${parts.join(' • ')}\n${constraints}`;
    setPrompt(full);
    return full;
  }

  async function generate() {
    try {
      setLoading(true);
      setError(null);
      setImages([]);
      const built = buildPrompt();
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: built }),
      });
      const data = await res.json();
      setImages(data.images || []);
    } catch (e: any) {
      setError('Oups, génération impossible. Réessaie.');
    } finally {
      setLoading(false);
    }
  }

  function applyPreset(p: (typeof PRESETS)[number]) {
    setShape(p.shape);
    setLength(p.length);
    setColors(p.colors);
    setMotifs(p.motifs);
    setVibe(p.vibe);
  }

  function exportPDF() {
    const doc = new jsPDF({ unit: 'pt', format: 'a4' });
    const margin = 40;
    let y = margin;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.text('Brief – Kit Press‑On personnalisé', margin, y);
    y += 20;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(11);
    const lines = [
      `Forme: ${shape || '—'}`,
      `Longueur: ${length || '—'}`,
      `Couleurs: ${colors || '—'}`,
      `Motifs/déco: ${motifs || '—'}`,
      `Ambiance/style: ${vibe || '—'}`,
    ];
    lines.forEach((l) => { doc.text(l, margin, y); y += 16; });

    y += 8;
    doc.setFont('helvetica', 'bold');
    doc.text('Prompt généré', margin, y);
    y += 14;
    doc.setFont('helvetica', 'normal');
    const promptSplit = doc.splitTextToSize(prompt || buildPrompt(), 515);
    doc.text(promptSplit, margin, y);
    y += promptSplit.length * 14 + 10;

    doc.setFont('helvetica', 'bold');
    doc.text('Tailles (gauche → droite)', margin, y);
    y += 16;
    doc.setFont('helvetica', 'normal');
    const fingers = ['Pouce','Index','Majeur','Annulaire','Auriculaire'];
    fingers.forEach((f, i) => {
      const left = sizesLeft[i] || '—';
      const right = sizesRight[i] || '—';
      doc.text(`${f}: G ${left} | D ${right}`, margin, y);
      y += 14;
    });

    if (notes) {
      y += 10;
      doc.setFont('helvetica', 'bold');
      doc.text('Notes', margin, y);
      y += 14;
      doc.setFont('helvetica', 'normal');
      const notesSplit = doc.splitTextToSize(notes, 515);
      doc.text(notesSplit, margin, y);
      y += notesSplit.length * 14 + 6;
    }

    if (images.length) {
      y += 8;
      doc.setFont('helvetica', 'bold');
      doc.text('Visuels (miniatures)', margin, y);
      y += 14;
      const thumbW = 110, thumbH = 80, gap = 10;
      let x = margin;
      for (let i = 0; i < images.length; i++) {
        doc.rect(x, y, thumbW, thumbH);
        doc.text(`Image ${i+1}`, x + 8, y + 16);
        x += thumbW + gap;
        if (x + thumbW > doc.internal.pageSize.getWidth() - margin) {
          x = margin;
          y += thumbH + gap;
        }
      }
    }
    doc.save('brief-press-on.pdf');
  }

  const sizeOptions = ['0','1','2','3','4','5','6','7','8','9','10'];

  return (
    <div className="min-h-screen w-full bg-zinc-50 p-6">
      <div className="mx-auto max-w-6xl">
        <header className="mb-6 flex items-center justify-between">
          <h1 className="text-2xl md:text-3xl font-semibold">Crée ton kit <span className="italic">Press‑On</span> personnalisé</h1>
          <span className="text-sm text-zinc-500">Prototype en ligne</span>
        </header>

        <div className="grid lg:grid-cols-5 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <div>
              <h2 className="text-sm font-medium mb-2">Préréglages (idées en 1 clic)</h2>
              <div className="grid grid-cols-2 gap-2">
                {PRESETS.map((p) => (
                  <button key={p.label} onClick={() => applyPreset(p)} className="rounded-2xl border p-2 text-left hover:bg-zinc-100">
                    <div className="text-sm font-medium">{p.label}</div>
                    <div className="text-xs text-zinc-500 line-clamp-2">{p.shape} • {p.colors}</div>
                  </button>
                ))}
              </div>
            </div>

            <form onSubmit={(e)=>{e.preventDefault(); generate();}} className="space-y-3">
              <div>
                <label className="block text-sm font-medium">Forme</label>
                <input value={shape} onChange={(e)=>setShape(e.target.value)} placeholder="amande, coffin, ovale..." className="mt-1 w-full rounded-2xl border p-2"/>
              </div>
              <div>
                <label className="block text-sm font-medium">Longueur</label>
                <input value={length} onChange={(e)=>setLength(e.target.value)} placeholder="courte, moyenne, longue" className="mt-1 w-full rounded-2xl border p-2"/>
              </div>
              <div>
                <label className="block text-sm font-medium">Couleurs</label>
                <input value={colors} onChange={(e)=>setColors(e.target.value)} placeholder="bleu pastel, nude rosé, noir mat..." className="mt-1 w-full rounded-2xl border p-2"/>
              </div>
              <div>
                <label className="block text-sm font-medium">Motifs / décorations</label>
                <input value={motifs} onChange={(e)=>setMotifs(e.target.value)} placeholder="fleurs fines, chrome, paillettes, french..." className="mt-1 w-full rounded-2xl border p-2"/>
              </div>
              <div>
                <label className="block text-sm font-medium">Ambiance / style</label>
                <input value={vibe} onChange={(e)=>setVibe(e.target.value)} placeholder="doux et poétique, glam rock, minimal chic..." className="mt-1 w-full rounded-2xl border p-2"/>
              </div>
              <button type="submit" disabled={loading} className="w-full rounded-2xl bg-black text-white py-2 font-medium shadow">{loading ? 'Génération...' : 'Générer des visuels'}</button>
              <p className="text-xs text-zinc-500">Astuce : plus la description est précise, plus les idées seront pertinentes.</p>
            </form>

            <div>
              <h2 className="text-sm font-medium mb-2">Prompt généré (aperçu)</h2>
              <textarea readOnly value={prompt} className="w-full h-28 rounded-2xl border p-2 text-sm"/>
            </div>

            <div>
              <h2 className="text-sm font-medium">Tailles des ongles</h2>
              <label className="mt-2 flex items-center gap-2 text-sm">
                <input type="checkbox" checked={knowSizes} onChange={(e)=>setKnowSizes(e.target.checked)} />
                Je connais mes tailles (standards 0–10)
              </label>

              {knowSizes ? (
                <div className="mt-3 grid grid-cols-2 gap-3">
                  <div className="rounded-2xl border p-3">
                    <div className="text-sm font-medium mb-2">Main gauche</div>
                    {['Pouce','Index','Majeur','Annulaire','Auriculaire'].map((f, i)=> (
                      <div key={f} className="flex items-center justify-between gap-2 mb-2">
                        <span className="text-xs w-24">{f}</span>
                        <select value={sizesLeft[i]} onChange={(e)=>{ const cp=[...sizesLeft]; cp[i]=e.target.value; setSizesLeft(cp); }} className="rounded-xl border p-1 text-sm w-20">
                          <option value="">—</option>
                          {['0','1','2','3','4','5','6','7','8','9','10'].map(o=> <option key={o} value={o}>{o}</option>)}
                        </select>
                      </div>
                    ))}
                  </div>
                  <div className="rounded-2xl border p-3">
                    <div className="text-sm font-medium mb-2">Main droite</div>
                    {['Pouce','Index','Majeur','Annulaire','Auriculaire'].map((f, i)=> (
                      <div key={f} className="flex items-center justify-between gap-2 mb-2">
                        <span className="text-xs w-24">{f}</span>
                        <select value={sizesRight[i]} onChange={(e)=>{ const cp=[...sizesRight]; cp[i]=e.target.value; setSizesRight(cp); }} className="rounded-xl border p-1 text-sm w-20">
                          <option value="">—</option>
                          {['0','1','2','3','4','5','6','7','8','9','10'].map(o=> <option key={o} value={o}>{o}</option>)}
                        </select>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <p className="text-xs text-zinc-500 mt-2">Si tu ne connais pas tes tailles, je t’enverrai un guide de prise de mesures ou un kit de sizing.</p>
              )}

              <div className="mt-3">
                <label className="block text-sm font-medium mb-1">Notes / précisions</label>
                <textarea value={notes} onChange={(e)=>setNotes(e.target.value)} className="w-full h-20 rounded-2xl border p-2 text-sm" placeholder="Ex : je tape beaucoup au clavier ; je préfère court ; allergie à la colle, etc."/>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2">
                <button onClick={exportPDF} className="rounded-2xl border py-2">Exporter le brief en PDF</button>
                <a href="#" onClick={(e)=>{e.preventDefault(); exportPDF();}} className="rounded-2xl bg-emerald-600 text-white py-2 text-center shadow">Télécharger & envoyer</a>
              </div>
            </div>
          </div>

          <div className="lg:col-span-3">
            <div className="rounded-3xl overflow-hidden shadow border relative">
              <div className="relative">
                <img src={wood} alt="planche bois" className="w-full h-72 md:h-96 object-cover"/>
                <div className="absolute inset-0 bg-white/10"/>
                <div className="absolute inset-0 p-4 md:p-6 flex flex-col">
                  <div className="flex items-center justify-between">
                    <div className="text-white/90 text-sm md:text-base font-medium drop-shadow">Nuancier – idées générées</div>
                    <div className="text-white/90 text-xs drop-shadow">{loading ? 'Génération...' : images.length ? `${images.length} échantillons` : 'en attente'}</div>
                  </div>
                  <div className="mt-3 grid grid-cols-4 gap-3 md:gap-4 place-items-center">
                    {loading && (<div className="col-span-4 text-white/90 text-sm">Création des visuels…</div>)}
                    {!loading && images.length === 0 && (<div className="col-span-4 text-white/90 text-sm">Aucun visuel pour l'instant. Lance une génération ou choisis un préréglage.</div>)}
                    {!loading && images.map((src, idx) => (<Tip key={idx} index={idx} src={src} />))}
                  </div>
                </div>
              </div>
            </div>

            {images.length > 0 && (
              <div className="mt-6 space-y-3">
                <button className="w-full rounded-2xl border py-2">Enregistrer ma sélection</button>
                <button className="w-full rounded-2xl bg-emerald-600 text-white py-2 shadow">Demander un devis / Commander ce kit</button>
                <p className="text-xs text-zinc-500">Le brief (prompt, tailles, miniatures) peut être exporté en PDF pour ta commande.</p>
              </div>
            )}
          </div>
        </div>

        <footer className="mt-10 text-xs text-zinc-500">
          <p>Prototype : idées sur nuancier bois. En production, les visuels seraient générés par l'IA et joints au brief PDF automatiquement.</p>
        </footer>
      </div>
    </div>
  );
}
