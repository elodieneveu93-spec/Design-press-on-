# Configurateur Press‑On – Déploiement Vercel

## Déploiement rapide
1. Sur vercel.com, créez un projet **New Project** puis **Import**.
2. Sélectionnez **Upload** et uploadez ce dossier sous forme de **.zip**.
3. Vercel détecte Next.js → cliquez **Deploy**.
4. Ouvrez l’URL générée.

## Option API IA (plus tard)
- Remplacez la route `app/api/generate/route.ts` par un appel réel (OpenAI / Stability / HF) et retournez `{ images: [] }`.
