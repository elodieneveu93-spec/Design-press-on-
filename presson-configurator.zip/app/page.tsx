import NailConfigurator from "@/components/NailConfigurator";

export default function Page() {
  return <NailConfigurator />;
}
